package com.example.deum2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class functionalLobbyActivity extends AppCompatActivity {
    public FirebaseAuth mAuth;
    public DatabaseReference mDatabase;
    public DataSnapshot userMap;
    public Button startGame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_functional_lobby);
        Intent intent = getIntent();
        TextView codeText= findViewById(R.id.code);
        // unload the code from the intent
        String code = intent.getStringExtra("code");
        codeText.setText("Code: " + code);
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance("https://deum-4666f-default-rtdb.europe-west1.firebasedatabase.app/").getReference();
        startGame = findViewById(R.id.createButton);
        FirebaseUser currentUser = mAuth.getCurrentUser();
        // get all the players from firebase using the game code (database location: Games, game code, players)
        // display the players in the list
        // create a listener to mDatabase.child("Games").child(code).child("players") that updates the list when a player joins
        ListView playerList = findViewById(R.id.playerList);
        mDatabase.child("Games").child(code).child("Players").addValueEventListener(
                new com.google.firebase.database.ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        userMap = snapshot;
                        HashMap users = (HashMap) snapshot.getValue();
                        assert users != null;
                        String[] players = new String[users.size()];
                        int i = 0;
                        for (Object user : users.values()) {
                            players[i] = (String) user;
                            i++;
                        }
                        playerList.setAdapter(new ArrayAdapter<>(functionalLobbyActivity.this, android.R.layout.simple_list_item_1, players));
                        Log.e("hello", "onDataChange: " + users.values());
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.w("L", "Failed to read value.", error.toException());
                    }
                }
        );
        
        
    }
    public void HostButtonReveal() {
        if (userMap.getChildrenCount() > 1 && getIntent().getBooleanExtra("isHost", false)) {
            startGame.setVisibility(Button.VISIBLE);
        }
        else {
            startGame.setVisibility(Button.INVISIBLE);
        }
    }
}